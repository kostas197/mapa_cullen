#!/bin/bash
docker compose up